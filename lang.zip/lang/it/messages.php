<?php

return [
    'success' => [
        'created' => 'creato con successo !',
        'updated' => 'aggiornato con successo !',
        'deleted' => 'eliminato con successo !',
    ],
    'error' => [
        'not_found' => 'Post not found!',
        'unauthorized' => 'You are not authorized to perform this action.',
    ],
];
