<?php

namespace App\Http\Requests\SportCategory;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\Rules\Password;
use App\Traits\SwitchDbConnection;

class UpdateSportCategoryRequest extends FormRequest
{
    use SwitchDbConnection;
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {

        $this->switchDatabase();

        return [
            'sportCategoryId' => 'required',
            'name'=> ['required', "unique:tenant.sport_categories,name,{$this->sportCategoryId}"],
            'description' => 'required',
        ];
    }

    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'message' => $validator->errors()
        ], 401));
    }

}
